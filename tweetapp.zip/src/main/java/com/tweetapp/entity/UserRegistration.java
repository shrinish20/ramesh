package com.tweetapp.entity;
import org.springframework.data.annotation.Id;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import java.util.Date;
@DynamoDBTable(tableName = "UserRegistration")
public class UserRegistration {
	@DynamoDBHashKey
	public String loginId;
	@DynamoDBAttribute
	public String firstName;
	@DynamoDBAttribute
	public String lastName;
	@DynamoDBAttribute
	public String contactNumber;
	@DynamoDBAttribute
    public String dob;
	@DynamoDBAttribute
    public String email;
	@DynamoDBAttribute
	public String password;
	
	

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

}
